celularl_marca = "samsung"
celular2_marca = "apple"
celular3_marca = "huawei"

celular1_modelo = "S23"
celular2_modelo= "iPhone 15 pro"
celular3_modelo = "P29 pro"

celularl_camaraT ="48MP"
celular2_camaraT ="48MP"
celular3_camaraT="12MP"

celularl_camaraF="24MP"
celular2_camaraF ="24MP"
celular3_camaraF="8MP"



print(celularl_camaraF)
