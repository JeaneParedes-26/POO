'POLIMORFISMO DE COERSION'

num1= 8
num2= 6.1

resultado = num1 + num2

print(resultado)
print(type(resultado))

